# THE FIRST PROMPT — paste this into Claude Code

> **How to use this file:**
> 1. Open terminal, `cd` into your empty GitHub repo for this project
> 2. Run `claude` to start Claude Code
> 3. Copy everything below the line and paste it as your first message
> 4. Claude will spend the next 60-90 minutes interviewing you, doing research, and writing the spec
> 5. **You write zero code in this session.** This is the Research + Refinement phase.

---

I am building a personal AI-powered job application command center. Working name: **CareerOS**. I am using Claude Code with a Spec-Driven Development methodology. **We are not writing application code in this session.** This session has one job: produce a complete, validated specification I can hand to a fresh implementation session.

## Ground rules for this session

1. **Read the four files in `docs/build-kit/` first**, in this order:
   - `01-product-brief.md` — what we're building and why
   - `02-sdd-workflow.md` — the four-phase methodology we're following
   - `03-CLAUDE-md-template.md` — the project memory file we'll create next
   - `04-prompt-library.md` — saved prompts I'll reference by name

2. **You are my AI Product Manager and Tech Lead.** I am the founder/PM. You interview me, you do research, you write specs. I review and approve at gates. Use the AskUserQuestion tool aggressively — never assume, always ask.

3. **Use subagents for all research.** When you need to investigate reference repositories, market patterns, or technical approaches, spawn parallel subagents with the Task tool. Main context stays clean. The phrase to use is: *"Spin up subagents to research X, Y, Z in parallel and report back."*

4. **Stop at every phase gate.** I approve before you proceed. Phase gates: Research → Spec → Refinement → Implementation Plan. No code until I approve the implementation plan.

5. **Honest gaps over plausible filler.** If you don't know something, say so. Ask. Search. Never invent.

## What we're going to do, in order

### Phase 1: Research (today, 30-45 min)

Spin up four parallel research subagents to investigate, in separate context windows:

- **Subagent A — Reference Architecture:** Read `santifer/career-ops` on GitHub. Map its directory structure, its CLAUDE.md, its skill files, its data contract (User Layer vs System Layer), its mode router pattern. Report what to copy and what to change for our use case.
- **Subagent B — Adjacent Tools:** Investigate `Pickle-Pixel/ApplyPilot` (browser-driven application submission), `olyaiy/resume-lm` (Next.js stack pattern), `Gsync/jobsync` (self-hosted tracker UX). Report what each does well and what we should borrow.
- **Subagent C — Claude Code Best Practices:** Read the Anthropic best practices docs and Boris Cherny's writing on Claude Code workflow. Surface the specific rules for CLAUDE.md size, skill structure, subagent delegation, hook patterns, and context window management. We will encode these as project rules.
- **Subagent D — Design Language:** Research Teenage Engineering's design principles (specifically the OP-1, OP-Z, TX-6, and Pocket Operator product lines). Identify the design tokens: typography (mono + grotesque), color (OP-1 white/orange/black, TX-6 dark), spatial rhythm, button/control vocabulary, label microtypography. Output a design tokens table.

Synthesize the four reports into `docs/research/synthesis.md`. **Wait for my approval before Phase 2.**

### Phase 2: Specification (today or tomorrow, 60-90 min)

Interview me using the AskUserQuestion tool to fill gaps in the product brief. Topics to probe:

- The four to five "job profile buckets" — what are mine, exactly, and what are the keyword/title/seniority filters for each?
- My full persona corpus — where do my resumes, cover letters, GitHub repos, certifications, and website content live? How will the tool ingest them?
- Email integration — Gmail vs Outlook, OAuth scope tolerance, what triggers an automatic state change vs a notification
- Auto-apply boundaries — which sites yes/no, what guardrails (dry-run flag, approval gate, daily cap)
- Outreach tone — founder vs colleague vs cold messaging, what voice patterns I want preserved
- Multi-profile support — am I building this only for me first, or designing the data model for N people from day one
- Privacy posture — local-first, self-hosted, or cloud; what data leaves my machine

Write `docs/spec/PRD.md` (Product Requirements Document) and `docs/spec/SPEC.md` (technical specification). **Wait for my approval before Phase 3.**

### Phase 3: Refinement (next session, 30-45 min)

You play the role of a skeptical staff engineer reviewing my spec. Stress-test it. Find:
- Ambiguities a Claude implementation session would resolve wrong
- Missing constraints (rate limits, error handling, state recovery)
- Hidden coupling between components
- Anything I said I want that conflicts with another thing I said I want

Write `docs/spec/REFINEMENT.md` with every gap and my answer to each. Update PRD and SPEC. **Wait for my approval before Phase 4.**

### Phase 4: Implementation Plan (final session of the build kit)

Decompose the spec into a wave-based task plan. Rules:
- Each task fits in 50% of a fresh context window
- Tasks marked `[P]` can run in parallel
- Each task has its own one-page brief: input files, output files, acceptance criteria, test command
- Group tasks into Waves (Wave 1 = foundations, Wave 2 = features that depend on Wave 1, etc.)

Write `docs/spec/TASKS.md` and one task brief per task in `docs/spec/tasks/`. **Wait for my approval. Then we begin implementation in fresh sessions, one task at a time.**

## How I want you to talk to me

- I am a strategy consultant, not a software engineer. Explain the *why* of every technical choice. If you say "we'll use Supabase," tell me what Supabase is, what it replaces, and what we lose by choosing it.
- Treat every choice as a tradeoff. Surface the alternatives you considered and the reason you picked one.
- When I make a decision that's likely wrong, push back once with the counter-argument. If I still want my way, do it my way and note the disagreement in the spec.
- Mark every assumption with `ASSUMPTION:` so I can challenge them later.

## Your first move

1. Confirm you've read all four files in `docs/build-kit/`
2. Tell me what you understood the goal to be, in your own words, in three sentences
3. Tell me what you're unsure about
4. Then spin up the four research subagents

Go.
