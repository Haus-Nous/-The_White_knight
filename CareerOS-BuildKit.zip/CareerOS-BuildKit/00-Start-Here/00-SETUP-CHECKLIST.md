# BEFORE YOU PASTE THE FIRST PROMPT — 15 minute setup

This is the entire setup. Do these steps in order, then open Claude Code.

## 1. Make the GitHub repository (5 min)

You said you've already created one. Confirm:

```bash
cd ~                                    # or wherever you keep code
git clone <your-repo-url> careerOS      # whatever you named it
cd careerOS
```

If the repo is empty, fine. If it has anything in it, that's also fine — we'll work around it.

## 2. Install Claude Code (5 min, skip if already installed)

Anthropic's official install:

```bash
# macOS / Linux
curl -fsSL https://claude.ai/install.sh | sh

# Or via npm if you prefer
npm install -g @anthropic-ai/claude-code
```

Check: `claude --version` should print a version. If not, restart your terminal.

You'll need a Claude Pro or Max plan, or an API key with credits.

## 3. Drop the build kit into the repo (2 min)

From the folder this build kit is in:

```bash
mkdir -p ~/careerOS/docs/build-kit
cp 01-Product-Brief/product-brief.md      ~/careerOS/docs/build-kit/01-product-brief.md
cp 02-Spec-Driven-Workflow/sdd-workflow.md ~/careerOS/docs/build-kit/02-sdd-workflow.md
cp 03-Claude-Code-Files/CLAUDE.md          ~/careerOS/CLAUDE.md
cp 03-Claude-Code-Files/CLAUDE-template-explained.md ~/careerOS/docs/build-kit/03-CLAUDE-md-template.md
cp 04-Prompt-Library/prompt-library.md    ~/careerOS/docs/build-kit/04-prompt-library.md
```

That's it. The rest of the kit (education, optimization playbook) lives in this folder for you to read whenever, not for Claude.

## 4. First commit (1 min)

```bash
cd ~/careerOS
git add .
git commit -m "chore: scaffold build kit and CLAUDE.md"
git push
```

Now your build kit is on GitHub.

## 5. Open Claude Code (30 sec)

```bash
cd ~/careerOS
claude
```

You'll see the prompt cursor.

## 6. Paste the first prompt

Open `00-Start-Here/01-FIRST-PROMPT.md` from this build kit. Copy everything below the horizontal rule. Paste into Claude Code.

Hit enter. Don't touch anything for the next 60-90 minutes except to answer Claude's questions.

## What to expect in the first session

- Claude reads the four build-kit files (~30 seconds)
- Claude tells you what it understood and what's unclear
- Claude spawns four parallel research subagents (~10-15 min, you watch)
- Claude synthesizes the research and writes `docs/research/synthesis.md`
- Claude pauses at the Phase 1 gate
- You read the synthesis, edit if needed, say "approved, proceed to Phase 2"
- Claude interviews you with the AskUserQuestion tool — answer thoughtfully
- Claude writes PRD.md and SPEC.md
- Claude pauses at the Phase 2 gate
- That's session 1. Commit, push, close.

## What NOT to do in the first session

- Do not write code
- Do not let Claude write code
- Do not approve a phase you haven't actually read
- Do not skip questions because they feel obvious — those are exactly where bugs hide
