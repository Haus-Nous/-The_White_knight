# Spec-Driven Development Workflow for CareerOS

> **Why this document exists:** Spec-Driven Development (SDD) is the methodology we're using to build CareerOS. It's documented in many places (panaversity SDD course, GitHub spec-kit, gotalab cc-sdd, anthropic best practices). This document compresses all of that into the version we'll actually use, customized to our project. Claude reads this to know what phase we're in and what's allowed.

## The four phases (and why)

```
Research → Specification → Refinement → Implementation
   |             |              |              |
gather       write down     find what's   break into
context        plan           missing      tasks & ship
```

The first three phases are slow and human-led. The fourth phase is fast and AI-led. **Most projects fail because the team rushes the first three phases.** This is not a productivity hack we are skipping.

### Phase 1 — Research

**Goal:** Gather enough context that the spec we write next is informed, not invented.

**What good looks like:** A `docs/research/synthesis.md` document that summarizes:
- What similar tools exist and what each does well/badly
- What technical patterns are proven for this problem
- What design language we're committing to (and why)
- What constraints we discovered we didn't know about

**What bad looks like:** "I read some stuff, here are some links."

**The discipline:** Use parallel subagents. Each subagent gets a narrow research question, a clean context window, and reports back a structured summary. The main agent never reads the source material — it reads only the summaries. This keeps your main context clean for the next phase.

**Gate:** I read the synthesis. I edit it where I disagree. I say "approved, proceed."

### Phase 2 — Specification

**Goal:** A document so clear that a fresh Claude session can implement from it without asking me anything.

**Two artifacts:**
1. `docs/spec/PRD.md` — Product Requirements Document. *What* are we building, *for whom*, *why*. User stories. Out-of-scope statements. Success metrics.
2. `docs/spec/SPEC.md` — Technical Specification. *How* we're building it. Architecture diagram. Data contract (User Layer vs System Layer). File and folder structure. Skill module list. Integration points. Error handling rules. Test strategy.

**The discipline:** Claude interviews me using the AskUserQuestion tool. Every ambiguous statement in the product brief gets at least one question. If I answer with "I don't know," that becomes an `OPEN QUESTION` in the spec, which we resolve in Phase 3.

**The trap to avoid:** Writing a spec that documents what Claude wants to build. The spec must document what *I* want, with Claude as the scribe.

**Gate:** I read both documents. I disagree where I disagree. I approve.

### Phase 3 — Refinement

**Goal:** Find the bugs in the spec before they become bugs in the code.

**The discipline:** Claude becomes a "skeptical staff engineer" reviewing my spec. A specific prompt pattern works well: *"You are a senior engineer who has shipped this kind of system before. Read SPEC.md. Find every ambiguity, every missing constraint, every place where the requirements contradict each other. Be ruthless. I will defend my choices afterward."*

The output is `docs/spec/REFINEMENT.md` — a list of gaps with my response to each. Spec gets updated.

**A second round helps:** Run the same prompt with a different framing — "you are a security reviewer," "you are the user three months from now reading this for the first time."

**Gate:** I approve the updated spec.

### Phase 4 — Implementation

**Goal:** Ship code, one task at a time, with each task fitting in a fresh context window.

**The discipline (this is "GSD" / aggressive atomicity):**
- Decompose the spec into 20-50 tasks
- Each task is sized to fit in **50% of a fresh 200K context window** (so plenty of room for the agent to think)
- Each task has its own one-page brief: `docs/spec/tasks/T-NN-<slug>.md`
- Tasks marked `[P]` can run in parallel (different files, no shared state)
- Each task = one commit
- Each session implements 1-3 tasks, then `/clear` and start fresh

**Why this matters:** Claude's quality drops as the context window fills. At 0-30% full it's at peak. At 50%+ it rushes. At 70%+ it hallucinates. By giving each task its own fresh session, every task gets peak Claude.

**Gate at every task:** I review the diff before commit.

## The phase gate ritual

At every gate, I run this exact prompt:

```
PHASE GATE — <phase name>

Show me:
1. The artifact you produced
2. The three biggest decisions you made and why
3. The three things you're least confident about
4. What changes if I disagree with each

Then stop. Do not proceed until I say "approved."
```

This forces Claude to surface its own uncertainty, which is where most spec bugs hide.

## What we explicitly do NOT do

- **No vibe coding.** No "let's just try it and see." Every change starts in a spec.
- **No skipping research.** Even when we think we know the answer.
- **No big sessions.** Sessions over 70% context get terminated and resumed fresh.
- **No CLAUDE.md bloat.** Every line earns its place. If removing it doesn't break anything, it goes.
- **No self-approving phases.** I gate every transition.

## When to break the rules

SDD is overhead, and overhead is only worth it when the alternative is worse. For CareerOS, the alternative is worse — this is a multi-session, multi-skill, multi-integration system that I'll be using daily for months. Spec drift would be expensive.

Inside the project, we will deliberately *not* use full SDD for:
- Skill module micro-changes that don't touch the data contract (e.g., tweaking the prompt in `tailor-resume/SKILL.md`)
- Bug fixes scoped to a single file
- Style and copy edits

For those, we use a lightweight pattern: 3-line description, change, commit. Anything bigger — full SDD.

## Reference materials I read while writing this

- panaversity/claude-code-sdd-exercises — the four-phase formulation
- github/spec-kit — the Specify/Plan/Tasks/Implement command vocabulary
- gotalab/cc-sdd — the kiro-discovery → kiro-spec-init → kiro-spec-requirements pattern
- Anthropic Claude Code best practices — context window management, subagent delegation
- alexop.dev "Spec-Driven Development with Claude Code in Action" — the concrete example
- ccforeveryone GSD framework — aggressive task atomicity (50% context budget per task)
