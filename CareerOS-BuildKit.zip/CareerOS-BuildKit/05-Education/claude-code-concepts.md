# Claude Code Concepts — Education

> **Audience:** you, building your first serious software product. This doc explains the Claude Code vocabulary you'll see used throughout the build, in plain language. Read it once now. Refer back when a term confuses you.

## The mental model in one paragraph

Claude Code is not a chatbot. It's an **agent runtime** — a process that runs in your terminal, has access to your filesystem and shell, can call tools, and can spawn other agents. The agent has a *context window* (roughly: short-term memory) of about 200K tokens. Everything you want it to know goes through that window. Everything that wastes the window degrades performance. The whole game of "using Claude Code well" is **context management**.

## The five primitives

Claude Code is built on five primitives. Once you know all five, you know the whole tool.

### 1. CLAUDE.md — persistent project memory

A markdown file at the root of your project. Claude reads it at the start of every session. It's "always on."

**What goes in:** rules that apply to every task, the project's basic shape, links to deeper docs.

**What does NOT go in:** specific workflows (those go in Skills), reference data (those are read on demand), rules that only apply sometimes.

**Analogy:** the safety briefing on a flight. Short, mandatory, every passenger hears it.

### 2. Skills — on-demand capabilities

A skill is a folder at `.claude/skills/<skill-name>/SKILL.md`. The SKILL.md has a YAML frontmatter (name, description) plus a markdown body.

Claude scans every skill's name+description on session start (~100 tokens per skill). When the user's request matches a skill's description, Claude loads the full body of that skill (1-5K tokens) and uses it as instructions.

**Why this matters:** you can have 50 skills installed without paying for them on every session. They cost nothing until triggered.

**Analogy:** a chef's recipe binder. Each recipe is its own page. The chef opens only the recipe needed for the current dish.

**The two kinds:** *capability uplift* skills give Claude abilities it doesn't have (like browser automation), and *encoded preference* skills enforce your style on capabilities Claude already has (like our `tailor-resume`).

### 3. Subagents — delegated workers

A subagent is a separate Claude instance spawned by the main agent for one specific task. The subagent has its own clean context window. When done, it returns only its final answer to the main agent — its intermediate work doesn't pollute the main session.

**Two flavors:**
- **Named subagents** (defined in `.claude/agents/<n>.md`) — preconfigured roles like our `research-investigator`
- **Unnamed forks** — spawned ad-hoc with the Task tool, inherit the conversation history

**Analogy:** hiring an intern for one job. They go off, do it, come back with the result. You don't have to listen to them think out loud.

**The single biggest leverage point in the entire tool.** Use subagents for any task involving heavy reading.

### 4. Hooks — deterministic enforcement

A hook is a shell script that runs automatically on a Claude Code event. Configured in `.claude/settings.json`.

The events are: `PreToolUse`, `PostToolUse`, `UserPromptSubmit`, `SessionStart`, `Stop`, `PreCompact`, etc. — see Anthropic's docs for the full list.

**Where hooks shine:** anything you can check with code. *"No em dashes in markdown files"* is a perfect hook — a `grep -c '\u2014' *.md` line either passes or fails. No LLM judgment required.

**Why hooks beat instructions:** they cost zero tokens, they run every time, they never get sloppy.

**Analogy:** a metal detector at airport security. Doesn't matter how tired the security agent is — the machine catches the metal.

### 5. MCP servers — external integrations

MCP (Model Context Protocol) is the protocol Claude Code uses to talk to external services. An MCP server is a small process that exposes some external capability (Gmail, Notion, a database, a browser) as tools Claude can call.

**Examples for our project:**
- Playwright MCP — browser automation for auto-apply
- Gmail MCP — read your inbox, parse interview emails
- GitHub MCP — read your repos, sync changes

**Analogy:** USB-C ports on a laptop. The protocol is standardized. You plug in any compatible device.

## The terminology you'll see

- **Vibe coding:** describing what you want to Claude in natural language and iterating until it works. Fast for prototypes. Bad for production. We're explicitly NOT doing this.
- **SDD (Spec-Driven Development):** the four-phase methodology we ARE doing. Research → Spec → Refinement → Implementation.
- **Aggressive atomicity:** breaking work into tasks small enough that each one fits in 50% of a fresh context window. From the GSD framework.
- **Context rot:** the quality degradation that happens as a session's context fills up. Real, measurable, plan around it.
- **Compaction:** when Claude summarizes the older parts of a session to save context space. Often loses important detail. Avoid by `/clear`-ing instead.
- **Plan Mode:** Claude Code's mode where it proposes its plan before executing. Toggle with shift-tab.
- **Slash commands:** `/clear`, `/compact`, `/btw`, `/usage`, etc. Built-in shortcuts.
- **Frontmatter:** the YAML block at the top of a SKILL.md or agent file. Metadata that controls when and how the file is loaded.

## The single mental shift

Most people use Claude Code like a chat. They type, it answers, they type, it answers. That works for a while. Then sessions get long, results degrade, and people blame the model.

The shift: **think of yourself as the architect of an AI workforce.** You're not chatting. You're configuring a team:

- CLAUDE.md is your team's standing orders
- Skills are your specialists
- Subagents are your contractors
- Hooks are your QA process
- MCP servers are your supply chain

Your job as the architect is to design the team well, then delegate. The job is *not* to do everything yourself in one long session.

This shift is the difference between getting 10x productivity from Claude Code and getting 1.5x. People who don't make the shift give up on Claude Code. People who do make it, ship products.

## Reading list (in priority order)

If you want to go deeper after this build kit:

1. **Anthropic's official Claude Code best practices** — `code.claude.com/docs/en/best-practices`. The single most important external doc.
2. **shanraisshan/claude-code-best-practice** GitHub repo — the most comprehensive third-party guide. Hundreds of tips with rationale.
3. **alexop.dev "Spec-Driven Development with Claude Code in Action"** — the concrete walkthrough that made SDD click for many people.
4. **santifer/career-ops** repo — read the CLAUDE.md, read the modes/ directory, read DATA_CONTRACT.md. This is the production system most similar to ours.
5. **panaversity/claude-code-sdd-exercises** — the 24-exercise course. If you want SDD in your bones, do these.
6. **github/spec-kit** — the Specify CLI and `/speckit.*` command vocabulary. Gives you a vocabulary even if you don't use the tool itself.

You don't need to read all of these. The build kit you're holding distills the relevant 80%. Read items 1 and 4, skim the rest, come back when you need them.
