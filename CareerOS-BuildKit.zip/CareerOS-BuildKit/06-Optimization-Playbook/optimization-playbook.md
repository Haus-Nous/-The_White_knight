# Claude Code Optimization Playbook

> **The honest framing:** there is no magic trick to bypass usage limits without paying. There ARE legitimate techniques that get you 3-5x more useful work out of the same number of tokens. That's the difference between burning through your weekly Pro quota in two days versus making it last the full week. This document is the second one.

## The mental model

Your single fundamental constraint in Claude Code is **the context window**, not the number of messages. Every token Claude sees in the context window costs you something — either directly (API) or against your rate limit (Pro/Max). Optimization is the discipline of giving Claude *exactly* the tokens it needs, no more.

Three failure modes consume tokens unnecessarily:

1. **Bloat** — CLAUDE.md, embedded files, accumulated conversation history that's no longer relevant
2. **Drift** — long sessions where Claude re-reads the same files, second-guesses earlier decisions, or rehashes context
3. **Wasted exploration** — Claude reads 30 files to answer a question that needed 3

Every technique below addresses one of those three.

## Technique 1 — Subagents for all research

The biggest single win.

**Without subagents:** Claude reads 30 files in your main context. Now your main session has 30 files of cruft, the answer to your question, and only 50K tokens left for the actual implementation.

**With subagents:** Spawn a subagent with the question. It reads 30 files in its own 200K context. It returns a 500-word summary. Your main session sees only the summary.

The phrase to use is *"Use a subagent to investigate X."* Or even better, *"Spin up three parallel subagents to investigate X, Y, Z."*

**When to use:**
- Any "find all the places where..."
- Any "research how Library Z does..."
- Any "compare these three approaches..."
- Any time Claude is about to read more than 5 files

**When NOT to use:**
- When the answer needs the full conversation context
- For tasks under 3 file reads (overhead exceeds benefit)
- For tasks where you need to see the intermediate work

## Technique 2 — Aggressive `/clear`

Default behavior: keep one session running for hours, accumulating context, getting progressively worse.

Better behavior: `/clear` between unrelated tasks. The data on context degradation:

| Context fill | Quality |
|---|---|
| 0-30% | Peak — comprehensive, careful, remembers everything |
| 30-50% | Good — slight rushing |
| 50-70% | Mediocre — cuts corners, "I'll be more concise" |
| 70%+ | Bad — hallucinations, forgotten requirements |
| 90%+ | Useless |

**Rule:** check context at the start of every major task. If it's over 50%, finish the current sub-task, write a handoff note, `/clear`, paste the handoff, continue. The 90 seconds you spend handing off saves 30 minutes of dealing with bad outputs.

**Use the `session-handoff` prompt from the prompt library.**

## Technique 3 — CLAUDE.md ruthlessness

CLAUDE.md is loaded into context on **every** session. A 500-line CLAUDE.md costs you the same number of tokens whether you used 5 of those rules or 50.

**Audit monthly:** for every line, ask "if I delete this, will Claude make a mistake?" If no, delete.

**Move detail out:**
- Specific workflows → Skills (loaded only when triggered)
- Reference data (rules, lists) → markdown files Claude reads on demand
- Things you can enforce in code → Hooks (run deterministically, no token cost)

**Target:** 50-100 lines max. Mine is 60ish.

## Technique 4 — Skills > prompts

If you find yourself pasting the same prompt structure twice, it's a skill.

**Why this saves tokens:** A skill loads ~100 tokens for its name+description (always available), and the body (1-5K tokens) loads only when triggered. A prompt you paste manually is in your conversation history forever.

**The career-os pattern:** every recurring task is a skill (`tailor-resume`, `ingest-jd`, `update-status`, etc.). The router skill (`career-os/SKILL.md`) dispatches to the right one. You never paste the resume rules again — they're in the skill.

## Technique 5 — Plan Mode for ambiguous tasks

Claude Code has a Plan Mode (`shift-tab` to enter). In Plan Mode, Claude proposes what it will do before doing it. You approve, then it executes.

**Why this saves tokens:** without plan mode, Claude often does the wrong thing, you correct, it retries. That's 3x the tokens vs. reviewing a plan first.

**Use Plan Mode for:** tasks with unclear scope, anything that touches >2 files, any first-time skill execution.

**Skip Plan Mode for:** trivial single-file edits, content drafts where iteration is part of the process.

## Technique 6 — Don't @-import large files into CLAUDE.md

When you write `@docs/big-file.md` in CLAUDE.md, Claude embeds the entire file in every session. That can be 5-10K tokens of pure waste if you only needed it once.

**Better:** reference it as a path. `"For the resume rules, see docs/resume-rules.md"`. Claude loads it when needed.

## Technique 7 — Hooks for deterministic enforcement

A hook is a script that runs automatically on a Claude Code event (PreToolUse, PostToolUse, SessionStart, etc.). Hooks run outside the LLM — they're plain shell scripts.

**Where hooks beat instructions:** anything you can check with code. Examples:
- Validate no em dashes in any markdown file before commit (PreCommit hook with grep)
- Block writes to `cv.md` or other User Layer files (PreToolUse hook on Write)
- Run paragraph-count check on every resume.md after generation (PostToolUse hook)

A hook costs zero tokens and never fails. An instruction in CLAUDE.md costs tokens every session and fails ~5% of the time.

**The trade:** writing the hook script takes 15 minutes. Worth it for any rule you've corrected Claude on more than twice.

## Technique 8 — Model selection

Claude Code supports model overrides per-skill and per-session. Use Haiku for cheap classification, Sonnet for general work, Opus for the hard stuff.

In a SKILL.md frontmatter:

```yaml
---
name: classify-jd
description: Quick classification of a JD by seniority and function
model: haiku
---
```

Haiku is roughly 1/15th the cost of Opus. For tasks that don't need deep reasoning (classification, formatting, simple extraction), it's free wins.

**Where to use Opus:** spec writing, refinement, hard architectural decisions
**Where to use Sonnet (the default):** most implementation, most tailoring
**Where to use Haiku:** classification, simple extraction, "is this a fit?" yes/no calls

## Technique 9 — `/btw` for one-off questions

Claude Code has a `/btw` command that opens a side overlay. The answer doesn't enter conversation history.

Use it for: "what's the syntax for X?", "is this library deprecated?", "what does this error mean?"

Without `/btw`, every aside lives in your context forever, slowly degrading the session. With `/btw`, asides cost nothing.

## Technique 10 — Don't fight the tool, change the tool

If you're correcting Claude on the same thing repeatedly, the fix is never "explain harder." The fix is one of:

- Add a rule to CLAUDE.md (if the rule should always apply)
- Create a skill (if it's a recurring workflow)
- Write a hook (if it's deterministic)
- Use a subagent (if it's a context pollution problem)
- Switch models (if it's a capability problem)

Three corrections = configure. Not "try again."

## What to do when you're hitting limits

If you're consistently bumping the Pro/Max rate limit, in priority order:

1. Audit CLAUDE.md size. Cut 30%.
2. Move all research to subagents.
3. `/clear` more aggressively. Three small sessions beat one long one.
4. Use Haiku for classification skills.
5. Use Plan Mode before any multi-file change.
6. Migrate frequently-paid prompts to skills.
7. Migrate deterministic rules to hooks.
8. If you're still hitting limits — your project is genuinely too big for the plan, upgrade or split into more sessions per day.

There is no #9 ("clever workaround"). The list above is the entire optimization stack.

## Migrating to Antigravity

Antigravity (Google's AI IDE, currently in beta) supports the same skills, the same MCP servers, and the same SDD patterns. The migration cost from Claude Code to Antigravity for our project is essentially zero — the `.claude/skills/` directory transfers over with a different installer (`npx antigravity-awesome-skills`).

**When to switch:**
- You want a richer GUI for diff review and file inspection
- You want Antigravity-specific features (e.g., subagent spawn behavior differs slightly)
- You hit Anthropic's rate limits and Google's free tier helps

**When NOT to switch:**
- Mid-implementation. Finish the current task in Claude Code, switch between tasks.
- If your skills depend on Claude Code-specific tools that haven't been ported yet (uncommon as of mid-2026)
