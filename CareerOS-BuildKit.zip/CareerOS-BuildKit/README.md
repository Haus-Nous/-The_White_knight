# CareerOS Build Kit

A complete starter kit for building **CareerOS** — a personal AI-powered job application command center — using Claude Code with Spec-Driven Development.

## The 30-second pitch

You are about to build a tool that ingests job descriptions, scores them against your target profiles, generates tailored resumes and cover letters in your voice, drafts founder/colleague outreach, optionally auto-applies on portals you whitelist, and tracks everything in one place. It learns your persona over time. It runs locally on your machine.

The reference architecture is `santifer/career-ops` (37k+ stars, used to evaluate 740+ jobs). We're extending the pattern, not inventing one.

## How to use this kit

1. Read `00-Start-Here/00-SETUP-CHECKLIST.md` — 15 minutes
2. Drop the build kit files into your repo as instructed
3. Open Claude Code, paste `00-Start-Here/01-FIRST-PROMPT.md`
4. Stop touching the keyboard for 60-90 minutes
5. Approve at each phase gate

## What's in the kit

```
CareerOS-BuildKit/
├── 00-Start-Here/
│   ├── 00-SETUP-CHECKLIST.md          # 15-min setup, do this first
│   └── 01-FIRST-PROMPT.md             # paste this into Claude Code
├── 01-Product-Brief/
│   └── product-brief.md               # the PRD that bootstraps the project
├── 02-Spec-Driven-Workflow/
│   └── sdd-workflow.md                # the four-phase methodology
├── 03-Claude-Code-Files/              # files that go in your repo
│   ├── CLAUDE.md                      # project memory, root of repo
│   ├── CLAUDE-template-explained.md   # why CLAUDE.md is structured this way
│   └── .claude/
│       ├── skills/
│       │   ├── career-os/SKILL.md     # main router skill
│       │   ├── tailor-resume/SKILL.md # resume generation skill
│       │   └── ingest-jd/SKILL.md     # JD parsing skill
│       └── agents/
│           └── research-investigator.md  # subagent for parallel research
├── 04-Prompt-Library/
│   └── prompt-library.md              # named prompts you'll reuse
├── 05-Education/
│   ├── claude-code-concepts.md        # primitives explained
│   └── ai-pm-workflow.md              # the build framed as PM craft
└── 06-Optimization-Playbook/
    └── optimization-playbook.md       # how to not burn through quota
```

## What goes in the repo vs what stays here

**Goes in your `careerOS/` repo (Claude reads these):**
- `03-Claude-Code-Files/CLAUDE.md` → repo root
- `03-Claude-Code-Files/.claude/` → repo root
- `01-Product-Brief/product-brief.md` → `docs/build-kit/01-product-brief.md`
- `02-Spec-Driven-Workflow/sdd-workflow.md` → `docs/build-kit/02-sdd-workflow.md`
- `03-Claude-Code-Files/CLAUDE-template-explained.md` → `docs/build-kit/03-CLAUDE-md-template.md`
- `04-Prompt-Library/prompt-library.md` → `docs/build-kit/04-prompt-library.md`

**Stays here (for you, not Claude):**
- `00-Start-Here/` — instructions for the human
- `05-Education/` — your learning material
- `06-Optimization-Playbook/` — your reference

## Phase map

```
Today (Session 1, ~90 min)
├── Phase 1: Research
│   └── 4 parallel subagents investigate reference repos, design language,
│       Claude Code best practices, and adjacent tools
└── Phase 2 (start): Specification interview
    └── Claude asks you the questions that fill gaps in product-brief.md

Tomorrow (Session 2, ~60 min)
├── Phase 2 (finish): write PRD.md and SPEC.md
└── PHASE GATE: you approve

Day 3 (Session 3, ~45 min)
├── Phase 3: Refinement
│   └── Claude plays adversarial reviewer, finds spec bugs
├── Spec gets updated
└── PHASE GATE: you approve

Day 4 (Session 4, ~60 min)
├── Phase 4: Implementation Plan
│   └── Spec decomposed into wave-based atomic tasks
└── PHASE GATE: you approve

Day 5+: Implementation begins, one task per session
```

Total time to first working v1: **2-3 weeks of focused evening work**.

## What v1 looks like when it ships

You can run, in your terminal:

```bash
cd ~/careerOS
claude
```

Then paste a JD URL or text. Claude:
- Ingests the JD into `applications/<slug>/jd.md`
- Scores it against your active buckets
- If the score is good, generates a tailored resume, cover letter, and three outreach drafts
- Shows you everything for approval
- Logs the application in your tracker

Plus:
- `/career-os scan` finds new jobs across LinkedIn and configurable career pages
- Natural language updates: *"got a call from Bain, second round Tuesday"* → status updated
- Email integration: interview emails auto-attach to the application
- Weekly review: structured retro every Friday

## Migrating to Antigravity

The build kit is platform-portable. When you want to move to Google's Antigravity IDE, run:

```bash
npx antigravity-awesome-skills --antigravity
```

The same `.claude/skills/` directory works. Same SKILL.md format. Same subagent contracts. The migration is a configuration swap, not a rewrite.

## The bet behind this kit

Most "build a job tracker" guides give you templates. This one gives you a methodology.

The bet: **for a product you'll use daily for months, the time spent learning Spec-Driven Development pays back within the first week.** You'll make better decisions, ship faster, and have a system you can extend without breaking.

If you want a pre-built tracker, fork career-ops directly and customize it. If you want to learn how to build AI products, use this kit.

## What to read first if you're impatient

- `00-Start-Here/00-SETUP-CHECKLIST.md` (5 min)
- `01-Product-Brief/product-brief.md` (15 min)
- `00-Start-Here/01-FIRST-PROMPT.md` (5 min)

That's 25 minutes. Then you can start.

## What to read when you have time

- `05-Education/ai-pm-workflow.md` — the PM mental model
- `05-Education/claude-code-concepts.md` — the technical vocabulary
- `06-Optimization-Playbook/optimization-playbook.md` — how to make your quota last

## Credits and references

This kit is synthesized from:

- **santifer/career-ops** — the reference architecture (37k+ GitHub stars)
- **Pickle-Pixel/ApplyPilot** — the auto-apply pattern
- **github/spec-kit** — the SDD command vocabulary
- **panaversity/claude-code-sdd-exercises** — the four-phase methodology
- **gotalab/cc-sdd** — multi-platform skill harness
- **Anthropic Claude Code best practices** — official guidance
- **shanraisshan/claude-code-best-practice** — community-distilled lessons
- **alexop.dev** — concrete SDD walkthroughs
- **ccforeveryone GSD framework** — aggressive task atomicity

Plus the conversation we've had over multiple sessions producing your existing 25+ tailored resumes, which gave us the rule corpus that's now encoded in the skills.

Build well. Ship something real.
