# Prompt Library

> **What this is:** the prompts I'll reuse across sessions, named so I can paste "use prompt: phase-gate" instead of retyping. Claude reads this file when the user references a named prompt.

## phase-gate

```
PHASE GATE — <phase name>

Show me:
1. The artifact you produced (file path)
2. The three biggest decisions you made and why
3. The three things you're least confident about
4. What changes if I disagree with each

Then stop. Do not proceed until I say "approved."
```

## research-spawn

```
Spin up <N> parallel research subagents using the research-investigator agent. Each gets one specific question. Run them in parallel. When all four return, synthesize the reports into <output-file>. Do not read the source material yourself — read only the subagent reports.

Subagent A — <question 1>
Subagent B — <question 2>
Subagent C — <question 3>
Subagent D — <question 4>
```

## skeptical-reviewer

```
You are now playing a different role. You are a senior engineer who has shipped systems like this one before. You did not write this spec — someone else did, and you're reviewing it for the first time.

Read <spec file path>. Find:
1. Every ambiguity that a fresh implementer would resolve wrong
2. Every missing constraint (rate limits, error cases, recovery flows)
3. Every place where two requirements contradict each other
4. Every assumption that isn't marked as one

Be ruthless. I will defend my choices afterward.

Output: docs/spec/REFINEMENT.md with each gap as a numbered item, your concern, and three sentences of reasoning.
```

## task-decompose

```
Decompose <spec file path> into a wave-based task plan.

Rules:
- Each task fits in 50% of a fresh 200K context window. If a task is bigger, split it.
- Each task = one commit
- Tasks marked [P] can run in parallel (no shared file writes, no shared state)
- Group tasks into Waves. Wave 1 = foundations. Wave 2 = depends only on Wave 1. Etc.
- Each task gets its own one-page brief at docs/spec/tasks/T-NN-<slug>.md with: input files, output files, acceptance criteria, test command, estimated context size

Output: docs/spec/TASKS.md (the wave-ordered list) plus one task brief per task.
```

## task-implement

```
Implement task <T-NN>.

Read:
1. docs/spec/tasks/T-NN-<slug>.md — your only instructions
2. Any input files it references
3. CLAUDE.md (always)

Do not read the rest of the spec. Do not read other task briefs. Stay scoped.

When done:
1. Show me the diff
2. Confirm acceptance criteria are met
3. Run the test command, paste the output
4. Wait for my approval before committing
```

## context-check

```
What's the current context window utilization? If it's over 60%, summarize what we've done so far in 5 bullets, then suggest we /clear and resume in a fresh session.
```

## update-claude-md

```
Look at the last <N> things I corrected you on. For each one:
1. Identify the rule that, if it had been in CLAUDE.md, would have prevented the mistake
2. Propose the exact line to add (10 words or fewer)
3. Identify any line currently in CLAUDE.md that's now redundant and can be deleted

Show me the proposed diff. Don't apply it without my approval.
```

## session-handoff

```
SESSION HANDOFF

We're closing this session at <X>% context. Before /clear, write a handoff note to docs/handoffs/<date>-<topic>.md containing:

1. What phase we're in
2. What I just approved (with file paths)
3. What's the next decision point
4. Any open questions
5. Any disagreements I overruled and the reasoning

Format so a fresh Claude session can read this file and continue without me re-explaining anything.
```

## tailor-resume-from-jd

```
Tailor a resume for the JD at applications/<slug>/jd.md.

Use the tailor-resume skill. Apply all 14 hard rules. Validate before exporting. Show me the markdown first, then the PDF.
```

## generate-cover-letter

```
Generate a cover letter for the application at applications/<slug>/.

Read jd.md, score.md, and persona/voice-samples.md. Match my actual writing tone — specific, declarative, no corporate filler. Single page. No em dashes. Output to applications/<slug>/cover-letter.md and .pdf.
```

## outreach-batch

```
For the application at applications/<slug>/, generate four outreach drafts in parallel:

1. Hiring manager cold email (LinkedIn first if you can identify them)
2. Internal referral ask — short, asks the contact if they'd be willing to refer
3. LinkedIn DM — under 300 chars, no asks, just opens conversation
4. Recruiter follow-up — for after I've applied, polite check-in

All drafts go in applications/<slug>/outreach/. Show me all four side by side. Wait for my edits.
```

## status-update-natural

```
I just had a conversation/update about an application. Here's what happened:

<paste the natural language update>

Parse it, identify which application it relates to, update applications/<slug>/status.yml and append to applications/<slug>/log.md. If you're unsure which application, ask me before updating anything.
```

## kill-application

```
Archive the application at applications/<slug>/.

Reason: <not-interested | rejected | withdrawn | stale-30d | accepted-elsewhere>

Move the folder to applications/_archived/<reason>/<slug>/. Update data/applications-index.tsv with the archive timestamp and reason. Do not delete anything — archive only.
```

## weekly-review

```
Run my weekly review.

1. List all applications still in 'sourced' status older than 7 days — propose archive
2. List all applications in 'applied' with no response after 14 days — propose follow-up
3. List all applications in 'interview' — what's the next action and when
4. Show top 5 highest-scored unapplied JDs from this week
5. Summarize: what worked this week, what didn't, one experiment to try next week

Output to docs/reviews/<ISO-week>.md.
```
